var structviennacl_1_1result__of_1_1value__type =
[
    [ "type", "structviennacl_1_1result__of_1_1value__type.html#a1fccdddb6d57eaba8f19506cea2051a3", null ]
];