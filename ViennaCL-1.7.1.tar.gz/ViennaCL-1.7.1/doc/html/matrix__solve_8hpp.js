var matrix__solve_8hpp =
[
    [ "matrix_solve", "structviennacl_1_1linalg_1_1opencl_1_1kernels_1_1matrix__solve.html", null ],
    [ "generate_matrix_solve_blas3", "matrix__solve_8hpp.html#a5db626a3b32b204504f4737f96982427", null ]
];