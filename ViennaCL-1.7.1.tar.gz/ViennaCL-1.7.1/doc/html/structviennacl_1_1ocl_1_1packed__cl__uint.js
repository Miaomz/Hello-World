var structviennacl_1_1ocl_1_1packed__cl__uint =
[
    [ "internal_size", "structviennacl_1_1ocl_1_1packed__cl__uint.html#ab4fed39d6fdda2db5bcb5ec29c2537d0", null ],
    [ "size", "structviennacl_1_1ocl_1_1packed__cl__uint.html#a5f4dcdfd54664fb7859b27f3dec641c0", null ],
    [ "start", "structviennacl_1_1ocl_1_1packed__cl__uint.html#a7991987e7676fabb8d1cbc54eaa0ba01", null ],
    [ "stride", "structviennacl_1_1ocl_1_1packed__cl__uint.html#a457e1f554ae439501613c843b6dad189", null ]
];