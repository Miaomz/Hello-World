var namespaceviennacl_1_1device__specific_1_1builtin__database_1_1devices_1_1gpu_1_1amd_1_1northern__islands =
[
    [ "barts", "namespaceviennacl_1_1device__specific_1_1builtin__database_1_1devices_1_1gpu_1_1amd_1_1northern__islands_1_1barts.html", null ],
    [ "devastator", "namespaceviennacl_1_1device__specific_1_1builtin__database_1_1devices_1_1gpu_1_1amd_1_1northern__islands_1_1devastator.html", null ],
    [ "scrapper", "namespaceviennacl_1_1device__specific_1_1builtin__database_1_1devices_1_1gpu_1_1amd_1_1northern__islands_1_1scrapper.html", null ]
];