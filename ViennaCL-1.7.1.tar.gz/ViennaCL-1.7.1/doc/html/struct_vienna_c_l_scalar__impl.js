var struct_vienna_c_l_scalar__impl =
[
    [ "backend", "struct_vienna_c_l_scalar__impl.html#a67d292f8863e566d0efb1f04708264d9", null ],
    [ "host_mem", "struct_vienna_c_l_scalar__impl.html#a995d0345857ac7a6ad47e13021b9abb9", null ],
    [ "offset", "struct_vienna_c_l_scalar__impl.html#a723dd4b75586c0d500b122db2458eb86", null ],
    [ "precision", "struct_vienna_c_l_scalar__impl.html#af8a28d7c016b5c0b811c46a4bcb4b7c2", null ]
];