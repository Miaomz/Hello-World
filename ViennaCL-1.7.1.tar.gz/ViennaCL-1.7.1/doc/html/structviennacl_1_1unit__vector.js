var structviennacl_1_1unit__vector =
[
    [ "unit_vector", "structviennacl_1_1unit__vector.html#acf1edf2697940a7321bdfc8b4e4d459a", null ]
];