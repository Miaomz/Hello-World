var classviennacl_1_1context =
[
    [ "context", "classviennacl_1_1context.html#a8f95db066e453ccd52aa9305fbd71243", null ],
    [ "context", "classviennacl_1_1context.html#a88b51d155aee396ef6d8d8a96bd7e90a", null ],
    [ "memory_type", "classviennacl_1_1context.html#aadf575d49ed144e8fa4707cdad69c349", null ]
];