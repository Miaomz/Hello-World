var classviennacl_1_1linalg_1_1row__scaling_3_01_matrix_type_00_01true_01_4 =
[
    [ "row_scaling", "classviennacl_1_1linalg_1_1row__scaling_3_01_matrix_type_00_01true_01_4.html#a1bd03c552dcc799006641e233da7c301", null ],
    [ "apply", "classviennacl_1_1linalg_1_1row__scaling_3_01_matrix_type_00_01true_01_4.html#a23fc95af614b76b6c6a152a44dfa5f7c", null ],
    [ "init", "classviennacl_1_1linalg_1_1row__scaling_3_01_matrix_type_00_01true_01_4.html#ad808b8c0aa51c598225e6d1807df2ab1", null ]
];