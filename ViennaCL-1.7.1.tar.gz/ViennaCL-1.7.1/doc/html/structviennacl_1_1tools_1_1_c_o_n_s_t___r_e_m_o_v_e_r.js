var structviennacl_1_1tools_1_1_c_o_n_s_t___r_e_m_o_v_e_r =
[
    [ "ResultType", "structviennacl_1_1tools_1_1_c_o_n_s_t___r_e_m_o_v_e_r.html#a4f041902878a4ffb6c8f1ffa55f759c3", null ]
];