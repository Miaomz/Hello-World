var classviennacl_1_1device__specific_1_1mapped__implicit__matrix =
[
    [ "mapped_implicit_matrix", "classviennacl_1_1device__specific_1_1mapped__implicit__matrix.html#a033ca22550d05eb5f3320aa1aa16143e", null ],
    [ "append_kernel_arguments", "classviennacl_1_1device__specific_1_1mapped__implicit__matrix.html#af6e1c36afa1485e3fe0786051b091c47", null ]
];