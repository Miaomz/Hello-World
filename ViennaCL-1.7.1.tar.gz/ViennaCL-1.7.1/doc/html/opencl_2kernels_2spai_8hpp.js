var opencl_2kernels_2spai_8hpp =
[
    [ "spai", "structviennacl_1_1linalg_1_1opencl_1_1kernels_1_1spai.html", null ],
    [ "generate_spai_assemble_blocks", "opencl_2kernels_2spai_8hpp.html#a6fc75b18244da56426784cbf789c030c", null ],
    [ "generate_spai_block_bv_assembly", "opencl_2kernels_2spai_8hpp.html#a947e6322493e8087cfd86d03fd858189", null ],
    [ "generate_spai_block_least_squares", "opencl_2kernels_2spai_8hpp.html#a8aa3b4bed4795a77017bf4419fd3b180", null ],
    [ "generate_spai_block_q_mult", "opencl_2kernels_2spai_8hpp.html#a59c4e99f39339ce7adfbb4793ec9a90f", null ],
    [ "generate_spai_block_qr", "opencl_2kernels_2spai_8hpp.html#a46c06e71a895b596b14c63ebc30d6da0", null ],
    [ "generate_spai_block_qr_assembly", "opencl_2kernels_2spai_8hpp.html#a0ef446958eadb7566af5af164c42d753", null ],
    [ "generate_spai_block_qr_assembly_1", "opencl_2kernels_2spai_8hpp.html#af432061aaf6283a75ec3b81ac0ab0f48", null ],
    [ "generate_spai_block_r_assembly", "opencl_2kernels_2spai_8hpp.html#a684d46d7a6d25da9315a650389a6b9a6", null ]
];