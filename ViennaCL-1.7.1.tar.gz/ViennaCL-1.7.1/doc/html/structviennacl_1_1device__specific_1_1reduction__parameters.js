var structviennacl_1_1device__specific_1_1reduction__parameters =
[
    [ "reduction_parameters", "structviennacl_1_1device__specific_1_1reduction__parameters.html#abf01b27ceb1be3066c5436d08c51a34e", null ],
    [ "fetching_policy", "structviennacl_1_1device__specific_1_1reduction__parameters.html#a9e1dd78718fc464c39afc7b2c3547179", null ],
    [ "num_groups", "structviennacl_1_1device__specific_1_1reduction__parameters.html#a539b1a9c7d202a007c70b4bc03ba1232", null ]
];