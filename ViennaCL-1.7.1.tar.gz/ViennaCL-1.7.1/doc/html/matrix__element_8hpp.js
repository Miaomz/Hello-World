var matrix__element_8hpp =
[
    [ "matrix_element", "structviennacl_1_1linalg_1_1opencl_1_1kernels_1_1matrix__element.html", null ],
    [ "generate_matrix_unary_element_ops", "matrix__element_8hpp.html#a8dfca8c806423d7228e3edcc5027b06a", null ],
    [ "generate_matrix_unary_element_ops", "matrix__element_8hpp.html#a8b32385dbd2b84db70eb4d9c5fc37190", null ]
];