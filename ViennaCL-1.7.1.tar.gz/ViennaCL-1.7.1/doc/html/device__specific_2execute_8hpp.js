var device__specific_2execute_8hpp =
[
    [ "execute", "device__specific_2execute_8hpp.html#a0e0576421dc6e48555abd251d0a83ae0", null ]
];