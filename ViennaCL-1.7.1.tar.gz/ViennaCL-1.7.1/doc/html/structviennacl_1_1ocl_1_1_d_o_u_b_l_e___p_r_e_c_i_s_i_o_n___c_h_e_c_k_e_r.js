var structviennacl_1_1ocl_1_1_d_o_u_b_l_e___p_r_e_c_i_s_i_o_n___c_h_e_c_k_e_r =
[
    [ "apply", "structviennacl_1_1ocl_1_1_d_o_u_b_l_e___p_r_e_c_i_s_i_o_n___c_h_e_c_k_e_r.html#ae23d18c854e1df43cd329a5c1fdd6d9f", null ]
];