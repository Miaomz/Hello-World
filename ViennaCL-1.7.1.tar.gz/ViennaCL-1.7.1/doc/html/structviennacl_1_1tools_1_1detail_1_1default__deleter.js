var structviennacl_1_1tools_1_1detail_1_1default__deleter =
[
    [ "operator()", "structviennacl_1_1tools_1_1detail_1_1default__deleter.html#ae823f00760b8da98484a4fb0e7ecc6e3", null ]
];