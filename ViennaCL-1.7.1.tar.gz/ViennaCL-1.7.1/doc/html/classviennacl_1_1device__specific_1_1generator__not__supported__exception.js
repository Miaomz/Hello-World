var classviennacl_1_1device__specific_1_1generator__not__supported__exception =
[
    [ "generator_not_supported_exception", "classviennacl_1_1device__specific_1_1generator__not__supported__exception.html#a05ed01a9dfc0888452f2cf48e9b0f841", null ],
    [ "generator_not_supported_exception", "classviennacl_1_1device__specific_1_1generator__not__supported__exception.html#af3989b0330ab76d1c512d9859b30abde", null ],
    [ "~generator_not_supported_exception", "classviennacl_1_1device__specific_1_1generator__not__supported__exception.html#a9d373df39b2436a4039b223890ee7d1e", null ],
    [ "what", "classviennacl_1_1device__specific_1_1generator__not__supported__exception.html#a81466e1e8d6d32902c9dc06b224e7682", null ]
];