var structviennacl_1_1linalg_1_1opencl_1_1kernels_1_1fft =
[
    [ "init", "structviennacl_1_1linalg_1_1opencl_1_1kernels_1_1fft.html#a30d107e22096060358bbd50b918c2d1e", null ],
    [ "program_name", "structviennacl_1_1linalg_1_1opencl_1_1kernels_1_1fft.html#a8424d60efaa28530b4ebd8d1b0773728", null ]
];