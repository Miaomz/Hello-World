var amg__base_8hpp =
[
    [ "amg_tag", "classviennacl_1_1linalg_1_1amg__tag.html", "classviennacl_1_1linalg_1_1amg__tag" ],
    [ "amg_level_context", "structviennacl_1_1linalg_1_1detail_1_1amg_1_1amg__level__context.html", "structviennacl_1_1linalg_1_1detail_1_1amg_1_1amg__level__context" ],
    [ "amg_coarsening_method", "amg__base_8hpp.html#a3ba810acdca541a5eada4560982a645c", [
      [ "AMG_COARSENING_METHOD_ONEPASS", "amg__base_8hpp.html#a3ba810acdca541a5eada4560982a645ca5167faa7286ca297508f581b26a048dc", null ],
      [ "AMG_COARSENING_METHOD_AGGREGATION", "amg__base_8hpp.html#a3ba810acdca541a5eada4560982a645ca867e1cc6319da3a2d502c9878d27170d", null ],
      [ "AMG_COARSENING_METHOD_MIS2_AGGREGATION", "amg__base_8hpp.html#a3ba810acdca541a5eada4560982a645ca0d4c883a9aa8a8514fb260ac404e3c8b", null ]
    ] ],
    [ "amg_interpolation_method", "amg__base_8hpp.html#a9933216144a64dbd433ec02c95bbfdd7", [
      [ "AMG_INTERPOLATION_METHOD_DIRECT", "amg__base_8hpp.html#a9933216144a64dbd433ec02c95bbfdd7a48d5bb166d266affee4d526e8671bec2", null ],
      [ "AMG_INTERPOLATION_METHOD_AGGREGATION", "amg__base_8hpp.html#a9933216144a64dbd433ec02c95bbfdd7a31dbd459c3ba8068280a6ec1bca00482", null ],
      [ "AMG_INTERPOLATION_METHOD_SMOOTHED_AGGREGATION", "amg__base_8hpp.html#a9933216144a64dbd433ec02c95bbfdd7afcffee5ed6e7ad032a9ffebe615b5932", null ]
    ] ]
];